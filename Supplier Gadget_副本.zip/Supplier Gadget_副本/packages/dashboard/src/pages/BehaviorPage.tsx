import { useEvents, useJourneys } from '../api/queries';
import { useFilters } from '../hooks/useFilters';
import GradientBorderCard from '../components/GradientBorderCard';
import SankeyFlowDiagram from '../components/SankeyFlowDiagram';
import SourceTypeBreakdown from '../components/SourceTypeBreakdown';
import DropoffFunnel from '../components/DropoffFunnel';
import StepDurationChart from '../components/StepDurationChart';
import EntryExitTable from '../components/EntryExitTable';
import { LoadingState, ErrorState, EmptyState } from '../components/StatePrimitives';

export default function BehaviorPage() {
  const { filters } = useFilters();
  const eventsQuery = useEvents({ limit: 500, startTime: filters.startTime, endTime: filters.endTime, appId: filters.appId });
  const journeysQuery = useJourneys({ startTime: filters.startTime, endTime: filters.endTime, appId: filters.appId });

  const isLoading = eventsQuery.isLoading && journeysQuery.isLoading;
  const hasError = eventsQuery.error || journeysQuery.error;

  if (hasError) {
    return <ErrorState message="加载行为数据失败" onRetry={() => { eventsQuery.refetch(); journeysQuery.refetch(); }} />;
  }
  if (isLoading) return <LoadingState />;

  const events = eventsQuery.data?.items ?? [];
  const journeys = journeysQuery.data ?? [];

  if (events.length === 0 && journeys.length === 0) {
    return <EmptyState message="暂无行为路径数据" />;
  }

  return (
    <div className="page-enter">
      <h1 style={{ fontSize: 20, fontWeight: 600, marginBottom: 24, color: 'var(--text-primary)' }}>行为路径分析</h1>

      <GradientBorderCard style={{ marginBottom: 24 }} title="用户流转桑基图" subtitle="页面间流量与深度" accent="var(--accent)">
        <SankeyFlowDiagram journeys={journeys} />
      </GradientBorderCard>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
        <SourceTypeBreakdown events={events} />
        <DropoffFunnel events={events} />
      </div>

      <div style={{ marginBottom: 24 }}>
        <StepDurationChart events={events} />
      </div>

      <EntryExitTable events={events} />
    </div>
  );
}
