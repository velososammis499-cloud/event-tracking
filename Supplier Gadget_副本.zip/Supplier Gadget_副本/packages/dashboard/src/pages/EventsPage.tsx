import { useState, useMemo } from 'react';
import { useEvents } from '../api/queries';
import { useFilters } from '../hooks/useFilters';
import type { EventType } from '../api/types';
import GlowCard from '../components/GlowCard';
import { LoadingState, ErrorState, EmptyState } from '../components/StatePrimitives';

const EVENT_TYPES: { value: EventType | ''; label: string }[] = [
  { value: '', label: '全部类型' },
  { value: 'pageview', label: '页面浏览' },
  { value: 'click', label: '点击' },
  { value: 'impression', label: '曝光' },
  { value: 'form_interaction', label: '表单交互' },
  { value: 'dwell', label: '停留' },
  { value: 'custom', label: '自定义' },
];

const PAGE_SIZE = 20;

export default function EventsPage() {
  const { filters } = useFilters();
  const [typeFilter, setTypeFilter] = useState<EventType | ''>('');
  const [pathFilter, setPathFilter] = useState('');
  const [page, setPage] = useState(0);

  const { data, isLoading, error, refetch } = useEvents({
    limit: 500,
    startTime: filters.startTime,
    endTime: filters.endTime,
    appId: filters.appId,
    type: typeFilter || undefined,
    pagePath: pathFilter || undefined,
  });

  const filtered = useMemo(() => {
    let items = data?.items ?? [];
    if (pathFilter) {
      items = items.filter(e => e.pagePath.toLowerCase().includes(pathFilter.toLowerCase()));
    }
    return items;
  }, [data, pathFilter]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paged = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  if (error) return <ErrorState message="加载事件数据失败" onRetry={() => refetch()} />;
  if (isLoading) return <LoadingState />;
  if (!data || data.items.length === 0) return <EmptyState message="暂无事件数据" />;

  return (
    <div className="animated-in">
      <h1 style={{ fontSize: 20, fontWeight: 600, marginBottom: 24, color: 'var(--text-primary)' }}>事件浏览</h1>

      <div style={styles.filterBar}>
        <select
          value={typeFilter}
          onChange={e => { setTypeFilter(e.target.value as EventType | ''); setPage(0); }}
          style={styles.select}
        >
          {EVENT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
        </select>
        <input
          placeholder="页面路径筛选"
          value={pathFilter}
          onChange={e => { setPathFilter(e.target.value); setPage(0); }}
          style={styles.input}
        />
        <span style={styles.count}>共 {filtered.length} 条</span>
      </div>

      <GlowCard>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>类型</th>
              <th style={styles.th}>页面</th>
              <th style={styles.th}>标签</th>
              <th style={styles.th}>会话</th>
              <th style={styles.th}>时间</th>
            </tr>
          </thead>
          <tbody>
            {paged.map(e => (
              <tr key={e.id} style={styles.row}>
                <td style={styles.td}>
                  <span style={{ ...styles.badge, background: typeColor(e.type) }}>
                    {e.type}
                  </span>
                </td>
                <td style={styles.td}>
                  <span style={{ color: 'var(--accent)', fontSize: 13 }}>{e.pagePath}</span>
                </td>
                <td style={styles.td}>{e.label || '—'}</td>
                <td style={styles.td}>
                  <span style={{ color: 'var(--text-muted)', fontSize: 11 }}>{e.sessionId.slice(0, 8)}…</span>
                </td>
                <td style={{ ...styles.td, color: 'var(--text-muted)', fontSize: 12 }}>
                  {new Date(e.timestamp).toLocaleString('zh-CN')}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {totalPages > 1 && (
          <div style={styles.pagination}>
            <button
              style={styles.pageBtn}
              disabled={page === 0}
              onClick={() => setPage(p => p - 1)}
            >上一页</button>
            <span style={styles.pageInfo}>{page + 1} / {totalPages}</span>
            <button
              style={styles.pageBtn}
              disabled={page >= totalPages - 1}
              onClick={() => setPage(p => p + 1)}
            >下一页</button>
          </div>
        )}
      </GlowCard>
    </div>
  );
}

function typeColor(type: EventType): string {
  const map: Record<string, string> = {
    pageview: 'rgba(0, 240, 255, 0.15)',
    click: 'rgba(0, 255, 136, 0.15)',
    impression: 'rgba(123, 47, 255, 0.15)',
    form_interaction: 'rgba(255, 184, 0, 0.15)',
    dwell: 'rgba(255, 51, 102, 0.15)',
    custom: 'rgba(138, 143, 168, 0.15)',
  };
  return map[type] || map.custom;
}

const styles: Record<string, React.CSSProperties> = {
  filterBar: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  select: {
    background: 'var(--bg-card)',
    border: '1px solid var(--border)',
    color: 'var(--text-primary)',
    padding: '6px 10px',
    borderRadius: 4,
    fontSize: 12,
    outline: 'none',
  },
  input: {
    background: 'var(--bg-card)',
    border: '1px solid var(--border)',
    color: 'var(--text-primary)',
    padding: '6px 10px',
    borderRadius: 4,
    fontSize: 12,
    width: 180,
    outline: 'none',
  },
  count: {
    fontSize: 12,
    color: 'var(--text-muted)',
  },
  table: { width: '100%', borderCollapse: 'collapse' },
  th: { textAlign: 'left', padding: '8px 12px', fontSize: 11, color: 'var(--text-muted)', borderBottom: '1px solid var(--border)', fontWeight: 500 },
  td: { padding: '10px 12px', fontSize: 13, borderBottom: '1px solid rgba(0, 240, 255, 0.06)' },
  row: { transition: 'background 0.1s' },
  badge: {
    padding: '2px 8px',
    borderRadius: 3,
    fontSize: 11,
    color: 'var(--text-secondary)',
  },
  pagination: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    marginTop: 16,
    paddingTop: 12,
    borderTop: '1px solid var(--border)',
  },
  pageBtn: {
    background: 'rgba(0, 240, 255, 0.06)',
    border: '1px solid var(--border)',
    color: 'var(--text-secondary)',
    padding: '4px 12px',
    borderRadius: 4,
    cursor: 'pointer',
    fontSize: 12,
  },
  pageInfo: {
    fontSize: 12,
    color: 'var(--text-muted)',
  },
};
