import { useMemo } from 'react';
import { usePages, useEvents } from '../api/queries';
import { useFilters } from '../hooks/useFilters';
import KpiCard from '../components/KpiCard';
import AnimatedNumber from '../components/AnimatedNumber';
import GlowCard from '../components/GlowCard';
import PageViewsChart from '../components/PageViewsChart';
import TopPagesTable from '../components/TopPagesTable';
import { LoadingState, ErrorState, EmptyState } from '../components/StatePrimitives';

export default function OverviewPage() {
  const { filters } = useFilters();
  const pages = usePages({ startTime: filters.startTime, endTime: filters.endTime, appId: filters.appId });
  const events = useEvents({ limit: 500, startTime: filters.startTime, endTime: filters.endTime, appId: filters.appId });

  const kpis = useMemo(() => {
    const pageData = pages.data ?? [];
    const totalViews = pageData.reduce((sum, p) => sum + p.views, 0);
    const totalSessions = pageData.reduce((sum, p) => sum + p.uniqueSessions, 0);
    const totalUsers = pageData.reduce((sum, p) => sum + p.uniqueUsers, 0);
    const totalEvents = events.data?.total ?? 0;
    return { totalViews, totalSessions, totalUsers, totalEvents };
  }, [pages.data, events.data]);

  const chartData = useMemo(() => {
    const items = events.data?.items ?? [];
    const byHour = new Map<string, number>();

    for (const e of items) {
      if (e.type !== 'pageview') continue;
      const d = new Date(e.timestamp);
      const key = `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:00`;
      byHour.set(key, (byHour.get(key) ?? 0) + 1);
    }

    return Array.from(byHour.entries())
      .map(([time, views]) => ({ time, views }))
      .sort((a, b) => a.time.localeCompare(b.time));
  }, [events.data]);

  const isLoading = pages.isLoading && events.isLoading;
  const hasError = pages.error || events.error;

  if (hasError) {
    return (
      <ErrorState
        message="加载分析数据失败"
        onRetry={() => { pages.refetch(); events.refetch(); }}
      />
    );
  }

  if (isLoading) return <LoadingState />;

  const pageData = pages.data ?? [];

  if (pageData.length === 0 && chartData.length === 0) {
    return <EmptyState message="暂无分析数据。打开示例页面 example/index.html 生成测试数据。" />;
  }

  return (
    <div className="animated-in">
      <h1 style={{ fontSize: 20, fontWeight: 600, marginBottom: 24, color: 'var(--text-primary)' }}>数据概览</h1>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        <KpiCard label="页面浏览量" value={kpis.totalViews} animated />
        <KpiCard label="会话数" value={kpis.totalSessions} animated />
        <KpiCard label="用户数" value={kpis.totalUsers} animated />
        <KpiCard label="事件总数" value={kpis.totalEvents} animated />
      </div>

      {chartData.length > 0 && (
        <div style={{ marginBottom: 24 }}>
          <GlowCard>
            <PageViewsChart data={chartData} />
          </GlowCard>
        </div>
      )}

      {pageData.length > 0 && <TopPagesTable data={pageData} />}
    </div>
  );
}
