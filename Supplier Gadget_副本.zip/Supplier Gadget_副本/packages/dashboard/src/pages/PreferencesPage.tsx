import { useEvents } from '../api/queries';
import { useFilters } from '../hooks/useFilters';
import ClickHeatMap from '../components/ClickHeatMap';
import AttentionRadar from '../components/AttentionRadar';
import PatternSequenceTree from '../components/PatternSequenceTree';
import FeatureUsageTimeline from '../components/FeatureUsageTimeline';
import EngagementScoreCard from '../components/EngagementScoreCard';
import { LoadingState, ErrorState, EmptyState } from '../components/StatePrimitives';

export default function PreferencesPage() {
  const { filters } = useFilters();
  const { data, isLoading, error, refetch } = useEvents({
    limit: 500,
    startTime: filters.startTime,
    endTime: filters.endTime,
    appId: filters.appId,
  });

  if (error) return <ErrorState message="加载偏好数据失败" onRetry={() => refetch()} />;
  if (isLoading) return <LoadingState />;

  const events = data?.items ?? [];
  if (events.length === 0) return <EmptyState message="暂无用户偏好数据" />;

  return (
    <div className="page-enter">
      <h1 style={{ fontSize: 20, fontWeight: 600, marginBottom: 24, color: 'var(--text-primary)' }}>偏好分析</h1>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
        <ClickHeatMap events={events} />
        <AttentionRadar events={events} />
      </div>

      <div style={{ marginBottom: 24 }}>
        <PatternSequenceTree events={events} />
      </div>

      <div style={{ marginBottom: 24 }}>
        <FeatureUsageTimeline events={events} />
      </div>

      <EngagementScoreCard events={events} />
    </div>
  );
}
