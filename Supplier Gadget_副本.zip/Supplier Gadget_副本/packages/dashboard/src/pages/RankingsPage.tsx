import { useMemo } from 'react';
import { useEvents } from '../api/queries';
import { useFilters } from '../hooks/useFilters';
import GlowCard from '../components/GlowCard';
import RankingBar from '../components/RankingBar';
import { LoadingState, ErrorState, EmptyState } from '../components/StatePrimitives';

export default function RankingsPage() {
  const { filters } = useFilters();
  const { data, isLoading, error, refetch } = useEvents({
    limit: 1000,
    startTime: filters.startTime,
    endTime: filters.endTime,
    appId: filters.appId,
  });

  const { clickRank, impressionRank, pageEngagement } = useMemo(() => {
    const items = data?.items ?? [];

    const clickMap = new Map<string, number>();
    const impressionMap = new Map<string, number>();
    const pageMap = new Map<string, { clicks: number; impressions: number; views: number }>();

    for (const e of items) {
      if (e.type === 'click') {
        const key = e.label || e.pagePath;
        clickMap.set(key, (clickMap.get(key) ?? 0) + 1);
      } else if (e.type === 'impression') {
        const key = e.label || e.pagePath;
        impressionMap.set(key, (impressionMap.get(key) ?? 0) + 1);
      }

      const page = e.pagePath;
      const entry = pageMap.get(page) ?? { clicks: 0, impressions: 0, views: 0 };
      if (e.type === 'click') entry.clicks++;
      else if (e.type === 'impression') entry.impressions++;
      else if (e.type === 'pageview') entry.views++;
      pageMap.set(page, entry);
    }

    const toRanked = (map: Map<string, number>) =>
      Array.from(map.entries())
        .map(([label, count]) => ({ label, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 20);

    const engagement = Array.from(pageMap.entries())
      .map(([pagePath, stats]) => ({ pagePath, ...stats }))
      .sort((a, b) => b.clicks - a.clicks);

    return { clickRank: toRanked(clickMap), impressionRank: toRanked(impressionMap), pageEngagement: engagement };
  }, [data]);

  if (error) return <ErrorState message="加载偏好数据失败" onRetry={() => refetch()} />;
  if (isLoading) return <LoadingState />;
  if (clickRank.length === 0 && impressionRank.length === 0) return <EmptyState message="暂无用户偏好数据" />;

  return (
    <div className="animated-in">
      <h1 style={{ fontSize: 20, fontWeight: 600, marginBottom: 24, color: 'var(--text-primary)' }}>用户偏好</h1>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
        <GlowCard>
          <RankingBar data={clickRank} title="点击排行" />
        </GlowCard>
        <GlowCard>
          <RankingBar data={impressionRank} title="曝光排行" />
        </GlowCard>
      </div>

      {pageEngagement.length > 0 && (
        <GlowCard>
          <h3 style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 16 }}>页面互动概览</h3>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>页面</th>
                <th style={{ ...styles.th, textAlign: 'right' }}>浏览</th>
                <th style={{ ...styles.th, textAlign: 'right' }}>点击</th>
                <th style={{ ...styles.th, textAlign: 'right' }}>曝光</th>
              </tr>
            </thead>
            <tbody>
              {pageEngagement.map(row => (
                <tr key={row.pagePath} style={styles.row}>
                  <td style={styles.td}><span style={{ color: 'var(--accent)', fontSize: 13 }}>{row.pagePath}</span></td>
                  <td style={{ ...styles.td, textAlign: 'right' }}>{row.views.toLocaleString()}</td>
                  <td style={{ ...styles.td, textAlign: 'right', color: 'var(--accent)' }}>{row.clicks.toLocaleString()}</td>
                  <td style={{ ...styles.td, textAlign: 'right', color: 'var(--purple)' }}>{row.impressions.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </GlowCard>
      )}
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  table: { width: '100%', borderCollapse: 'collapse' },
  th: { textAlign: 'left', padding: '8px 12px', fontSize: 11, color: 'var(--text-muted)', borderBottom: '1px solid var(--border)', fontWeight: 500 },
  td: { padding: '10px 12px', fontSize: 13, borderBottom: '1px solid rgba(0, 240, 255, 0.06)' },
  row: { transition: 'background 0.1s' },
};
