import { useJourneys } from '../api/queries';
import { useFilters } from '../hooks/useFilters';
import GlowCard from '../components/GlowCard';
import FlowDiagram from '../components/FlowDiagram';
import { LoadingState, ErrorState, EmptyState } from '../components/StatePrimitives';

export default function JourneysPage() {
  const { filters } = useFilters();
  const { data, isLoading, error, refetch } = useJourneys({
    startTime: filters.startTime,
    endTime: filters.endTime,
    appId: filters.appId,
  });

  if (error) return <ErrorState message="加载路径数据失败" onRetry={() => refetch()} />;
  if (isLoading) return <LoadingState />;
  if (!data || data.length === 0) return <EmptyState message="暂无路径数据" />;

  return (
    <div className="animated-in">
      <h1 style={{ fontSize: 20, fontWeight: 600, marginBottom: 24, color: 'var(--text-primary)' }}>路径分析</h1>

      <GlowCard style={{ marginBottom: 24 }}>
        <FlowDiagram journeys={data} />
      </GlowCard>

      <GlowCard>
        <h3 style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 16 }}>路径详情</h3>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>来源页面</th>
              <th style={styles.th}>目标页面</th>
              <th style={{ ...styles.th, textAlign: 'right' }}>次数</th>
            </tr>
          </thead>
          <tbody>
            {data.map((j, i) => (
              <tr key={`${j.sourcePath}-${j.targetPath}-${i}`} style={styles.row}>
                <td style={styles.td}><span style={{ color: 'var(--accent)', fontSize: 13 }}>{j.sourcePath}</span></td>
                <td style={styles.td}><span style={{ color: 'var(--purple)', fontSize: 13 }}>{j.targetPath}</span></td>
                <td style={{ ...styles.td, textAlign: 'right', color: 'var(--text-primary)' }}>{j.count.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </GlowCard>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  table: { width: '100%', borderCollapse: 'collapse' },
  th: { textAlign: 'left', padding: '8px 12px', fontSize: 11, color: 'var(--text-muted)', borderBottom: '1px solid var(--border)', fontWeight: 500 },
  td: { padding: '10px 12px', fontSize: 13, borderBottom: '1px solid rgba(0, 240, 255, 0.06)' },
  row: { transition: 'background 0.1s' },
};
