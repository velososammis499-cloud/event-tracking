import ChatWindow from '../components/ChatWindow';
import GlowCard from '../components/GlowCard';

export default function ChatPage() {
  return (
    <div className="page-enter">
      <h1 style={{ fontSize: 20, fontWeight: 600, marginBottom: 16, color: 'var(--text-primary)' }}>智能对话分析</h1>
      <GlowCard style={{ padding: 0, overflow: 'hidden' }}>
        <ChatWindow />
      </GlowCard>
    </div>
  );
}
