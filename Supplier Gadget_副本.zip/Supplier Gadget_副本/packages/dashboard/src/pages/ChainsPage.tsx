import { useChains } from '../api/queries';
import { useFilters } from '../hooks/useFilters';
import GlowCard from '../components/GlowCard';
import SessionTimeline from '../components/SessionTimeline';
import { LoadingState, ErrorState, EmptyState } from '../components/StatePrimitives';

export default function ChainsPage() {
  const { filters } = useFilters();
  const { data, isLoading, error, refetch } = useChains({
    appId: filters.appId,
    limit: 50,
  });

  if (error) return <ErrorState message="加载会话数据失败" onRetry={() => refetch()} />;
  if (isLoading) return <LoadingState />;
  if (!data || data.length === 0) return <EmptyState message="暂无会话追踪数据" />;

  return (
    <div className="animated-in">
      <h1 style={{ fontSize: 20, fontWeight: 600, marginBottom: 24, color: 'var(--text-primary)' }}>会话追踪</h1>

      <GlowCard>
        <h3 style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 16 }}>
          共 {data.length} 个会话
        </h3>
        <SessionTimeline chains={data} />
      </GlowCard>
    </div>
  );
}
