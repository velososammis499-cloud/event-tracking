import type { EventDTO, PageStatsDTO } from '../api/types';

export interface ChartSpec {
  type: 'bar' | 'pie' | 'line' | 'table';
  data: Array<Record<string, unknown>>;
  config: Record<string, unknown>;
}

export interface AnalysisResult {
  summary: string;
  chartData?: ChartSpec;
  confidence: 'high' | 'medium' | 'low';
}

type Analyzer = (events: EventDTO[], pages: PageStatsDTO[]) => AnalysisResult;

const dwellAnalyzer: Analyzer = (events) => {
  const dwellEvents = events.filter(e => e.type === 'dwell');
  if (dwellEvents.length === 0) {
    return { summary: '暂无停留时长数据。', confidence: 'low' };
  }
  const byPage = new Map<string, { total: number; count: number }>();
  for (const e of dwellEvents) {
    const entry = byPage.get(e.pagePath) ?? { total: 0, count: 0 };
    const dur = Number(e.label) || 0;
    entry.total += dur;
    entry.count += 1;
    byPage.set(e.pagePath, entry);
  }
  const ranked = Array.from(byPage.entries())
    .map(([pagePath, { total, count }]) => ({ pagePath, avgDuration: Math.round(total / count), count }))
    .sort((a, b) => b.avgDuration - a.avgDuration)
    .slice(0, 10);

  const top = ranked[0];
  const summary = ranked.length > 0
    ? `用户在「${top.pagePath}」停留最久，平均 ${top.avgDuration}ms。共统计了 ${ranked.length} 个页面的停留数据。`
    : '暂无停留时长数据。';

  return {
    summary,
    chartData: {
      type: 'bar',
      data: ranked.map(r => ({ name: r.pagePath, value: r.avgDuration })),
      config: { xKey: 'name', yKey: 'value', label: '平均停留时长(ms)' },
    },
    confidence: 'high',
  };
};

const sourceAnalyzer: Analyzer = (events) => {
  const bySource = new Map<string, { count: number; sessions: Set<string> }>();
  for (const e of events) {
    const t = e.sourceType || 'unknown';
    const entry = bySource.get(t) ?? { count: 0, sessions: new Set<string>() };
    entry.count++;
    entry.sessions.add(e.sessionId);
    bySource.set(t, entry);
  }
  const items = Array.from(bySource.entries()).map(([type, { count, sessions }]) => ({
    type,
    count,
    sessions: sessions.size,
  }));
  const total = items.reduce((s, i) => s + i.count, 0);
  const summary = items.length > 0
    ? `用户来源分布：${items.map(i => `${i.type} ${((i.count / total) * 100).toFixed(1)}%`).join('，')}。`
    : '暂无来源数据。';

  return {
    summary,
    chartData: {
      type: 'pie',
      data: items.map(i => ({ name: i.type, value: i.count })),
      config: { label: '来源类型' },
    },
    confidence: 'high',
  };
};

const clickAnalyzer: Analyzer = (events) => {
  const clickEvents = events.filter(e => e.type === 'click');
  if (clickEvents.length === 0) {
    return { summary: '暂无点击数据。', confidence: 'low' };
  }
  const byLabel = new Map<string, number>();
  for (const e of clickEvents) {
    const key = e.label || e.pagePath;
    byLabel.set(key, (byLabel.get(key) ?? 0) + 1);
  }
  const ranked = Array.from(byLabel.entries())
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  const top = ranked[0];
  const summary = `点击最多的功能是「${top.label}」，共 ${top.count} 次。`;

  return {
    summary,
    chartData: {
      type: 'bar',
      data: ranked.map(r => ({ name: r.label, value: r.count })),
      config: { xKey: 'name', yKey: 'value', label: '点击次数' },
    },
    confidence: 'high',
  };
};

const pageviewAnalyzer: Analyzer = (events, pages) => {
  if (pages.length === 0) {
    return { summary: '暂无页面浏览数据。', confidence: 'low' };
  }
  const top = pages.slice(0, 10);
  const summary = `浏览量最高的页面是「${top[0].pagePath}」，共 ${top[0].views} 次浏览。`;

  return {
    summary,
    chartData: {
      type: 'table',
      data: top.map(p => ({ 页面: p.pagePath, 浏览量: p.views, 会话数: p.uniqueSessions, 用户数: p.uniqueUsers })),
      config: { columns: ['页面', '浏览量', '会话数', '用户数'] },
    },
    confidence: 'high',
  };
};

const patternAnalyzer: Analyzer = (events) => {
  const bySession = new Map<string, EventDTO[]>();
  for (const e of events) {
    const list = bySession.get(e.sessionId) ?? [];
    list.push(e);
    bySession.set(e.sessionId, list);
  }

  const seqMap = new Map<string, number>();
  for (const [, evts] of bySession) {
    const sorted = [...evts].sort((a, b) => a.timestamp - b.timestamp);
    for (let len = 2; len <= 4; len++) {
      for (let i = 0; i <= sorted.length - len; i++) {
        const seq = sorted.slice(i, i + len).map(e => `${e.type}:${e.label || e.pagePath}`).join(' → ');
        seqMap.set(seq, (seqMap.get(seq) ?? 0) + 1);
      }
    }
  }

  const top = Array.from(seqMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  if (top.length === 0) {
    return { summary: '暂无足够数据识别操作模式。', confidence: 'low' };
  }

  const summary = `识别到 ${top.length} 种常见操作模式，最频繁的是「${top[0][0]}」，出现 ${top[0][1]} 次。`;

  return {
    summary,
    chartData: {
      type: 'table',
      data: top.map(([seq, count]) => ({ 操作序列: seq, 次数: count })),
      config: { columns: ['操作序列', '次数'] },
    },
    confidence: 'medium',
  };
};

const formAnalyzer: Analyzer = (events) => {
  const formEvents = events.filter(e => e.type === 'form_interaction');
  if (formEvents.length === 0) {
    return { summary: '暂无表单交互数据。', confidence: 'low' };
  }
  const byAction = new Map<string, number>();
  for (const e of formEvents) {
    const action = e.interactionType || 'unknown';
    byAction.set(action, (byAction.get(action) ?? 0) + 1);
  }
  const items = Array.from(byAction.entries())
    .sort((a, b) => b[1] - a[1]);

  const summary = `表单交互共 ${formEvents.length} 次：${items.map(([a, c]) => `${a} ${c}次`).join('，')}。`;

  return {
    summary,
    chartData: {
      type: 'bar',
      data: items.map(([name, value]) => ({ name, value })),
      config: { xKey: 'name', yKey: 'value', label: '交互次数' },
    },
    confidence: 'high',
  };
};

const dropoffAnalyzer: Analyzer = (events) => {
  const bySession = new Map<string, EventDTO[]>();
  for (const e of events) {
    if (e.type !== 'pageview') continue;
    const list = bySession.get(e.sessionId) ?? [];
    list.push(e);
    bySession.set(e.sessionId, list);
  }

  const exitMap = new Map<string, number>();
  for (const [, evts] of bySession) {
    const last = [...evts].sort((a, b) => a.timestamp - b.timestamp).pop();
    if (last) {
      exitMap.set(last.pagePath, (exitMap.get(last.pagePath) ?? 0) + 1);
    }
  }

  const exits = Array.from(exitMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  if (exits.length === 0) {
    return { summary: '暂无流失数据。', confidence: 'low' };
  }

  const totalSessions = bySession.size;
  const top = exits[0];
  const summary = `流失率最高的页面是「${top[0]}」，${top[1]} 个会话在此结束（占 ${((top[1] / totalSessions) * 100).toFixed(1)}%）。`;

  return {
    summary,
    chartData: {
      type: 'bar',
      data: exits.map(([name, value]) => ({ name, value })),
      config: { xKey: 'name', yKey: 'value', label: '流失会话数' },
    },
    confidence: 'high',
  };
};

const trendAnalyzer: Analyzer = (events) => {
  const byDay = new Map<string, Record<string, number>>();
  for (const e of events) {
    const d = new Date(e.timestamp);
    const key = `${d.getMonth() + 1}/${d.getDate()}`;
    const row = byDay.get(key) ?? {};
    row[e.type] = (row[e.type] || 0) + 1;
    byDay.set(key, row);
  }

  const sorted = Array.from(byDay.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  if (sorted.length === 0) {
    return { summary: '暂无趋势数据。', confidence: 'low' };
  }

  const summary = `共有 ${sorted.length} 天的数据记录，事件类型分布趋势已生成。`;

  return {
    summary,
    chartData: {
      type: 'line',
      data: sorted.map(([day, counts]) => ({ name: day, ...counts })),
      config: { xKey: 'name', lines: ['pageview', 'click', 'impression'] },
    },
    confidence: 'high',
  };
};

const analyzers: { keywords: string[]; analyze: Analyzer }[] = [
  { keywords: ['停留', 'dwell', '时长', '最久'], analyze: dwellAnalyzer },
  { keywords: ['从哪来', '来源', 'source', '入口'], analyze: sourceAnalyzer },
  { keywords: ['点击', 'click', '最多', '热门'], analyze: clickAnalyzer },
  { keywords: ['浏览', '访问', 'pageview', 'PV', 'pv'], analyze: pageviewAnalyzer },
  { keywords: ['行为', '操作', '习惯', 'pattern', '模式'], analyze: patternAnalyzer },
  { keywords: ['表单', 'form', '填写'], analyze: formAnalyzer },
  { keywords: ['流失', '跳出', '离开', 'exit', '跳出率', '流失率'], analyze: dropoffAnalyzer },
  { keywords: ['趋势', '变化', '增长', 'trend'], analyze: trendAnalyzer },
];

function fallbackAnalyzer(events: EventDTO[], pages: PageStatsDTO[]): AnalysisResult {
  const total = events.length;
  const types = new Set(events.map(e => e.type));
  const topPage = pages[0];
  const topClick = events.filter(e => e.type === 'click');
  const clickLabels = new Map<string, number>();
  for (const e of topClick) {
    const key = e.label || e.pagePath;
    clickLabels.set(key, (clickLabels.get(key) ?? 0) + 1);
  }
  const topClickItem = Array.from(clickLabels.entries()).sort((a, b) => b[1] - a[1])[0];

  let summary = `共 ${total} 条事件，覆盖 ${types.size} 种类型。`;
  if (topPage) summary += ` 浏览最多的页面：${topPage.pagePath}（${topPage.views}次）。`;
  if (topClickItem) summary += ` 点击最多的元素：${topClickItem[0]}（${topClickItem[1]}次）。`;
  summary += '\n\n可以问我：停留时长、来源分析、点击排行、操作习惯、流失率、趋势等。';

  return { summary, confidence: 'low' };
}

export function analyzeQuery(
  query: string,
  events: EventDTO[],
  pages: PageStatsDTO[],
): AnalysisResult {
  const lower = query.toLowerCase();
  for (const { keywords, analyze } of analyzers) {
    if (keywords.some(k => lower.includes(k.toLowerCase()))) {
      return analyze(events, pages);
    }
  }
  return fallbackAnalyzer(events, pages);
}
