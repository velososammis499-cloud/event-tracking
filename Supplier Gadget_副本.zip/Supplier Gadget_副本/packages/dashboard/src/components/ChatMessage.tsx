import { useEffect, useRef, useState } from 'react';
import type { AnalysisResult } from '../analysis/chat-analyzer';
import InlineChart from './InlineChart';

interface Props {
  role: 'user' | 'ai';
  content: string;
  chartData?: AnalysisResult['chartData'];
  animate?: boolean;
}

export default function ChatMessage({ role, content, chartData, animate }: Props) {
  const [displayed, setDisplayed] = useState(animate ? '' : content);
  const idxRef = useRef(0);

  useEffect(() => {
    if (!animate || !content) return;
    idxRef.current = 0;
    setDisplayed('');
    const interval = setInterval(() => {
      idxRef.current += 1;
      setDisplayed(content.slice(0, idxRef.current));
      if (idxRef.current >= content.length) clearInterval(interval);
    }, 25);
    return () => clearInterval(interval);
  }, [content, animate]);

  if (role === 'user') {
    return (
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 12 }}>
        <div style={{
          maxWidth: '70%',
          padding: '10px 14px',
          background: 'rgba(0, 240, 255, 0.08)',
          border: '1px solid rgba(0, 240, 255, 0.2)',
          borderRadius: '8px 8px 2px 8px',
          fontSize: 13,
          color: 'var(--text-primary)',
          lineHeight: 1.6,
        }}>
          {content}
        </div>
      </div>
    );
  }

  return (
    <div className="glitch-in" style={{ display: 'flex', justifyContent: 'flex-start', marginBottom: 12 }}>
      <div style={{
        maxWidth: '80%',
        padding: '12px 16px',
        background: 'var(--bg-card)',
        border: '1px solid var(--border)',
        borderRadius: '8px 8px 8px 2px',
        fontSize: 13,
        color: 'var(--text-secondary)',
        lineHeight: 1.6,
      }}>
        <div style={{ whiteSpace: 'pre-wrap' }}>{displayed}</div>
        {chartData && displayed === content && (
          <div style={{ marginTop: 10, paddingTop: 10, borderTop: '1px solid rgba(0, 240, 255, 0.08)' }}>
            <InlineChart chartData={chartData} />
          </div>
        )}
        {animate && displayed.length < content.length && (
          <span style={{ display: 'inline-block', width: 6, height: 12, background: 'var(--accent)', marginLeft: 2, animation: 'breathe 0.8s ease-in-out infinite' }} />
        )}
      </div>
    </div>
  );
}
