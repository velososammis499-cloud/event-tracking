import type { ChartSpec } from '../analysis/chat-analyzer';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line,
} from 'recharts';
import { sourceColors } from '../theme/cyberpunk';

const COLORS = ['#00f0ff', '#7b2fff', '#00ff88', '#ffb800', '#ff3366', '#8a8fa8'];

function InlineBar({ data, config }: { data: Array<Record<string, unknown>>; config: Record<string, unknown> }) {
  const xKey = (config.xKey as string) || 'name';
  const yKey = (config.yKey as string) || 'value';
  return (
    <ResponsiveContainer width="100%" height={160}>
      <BarChart data={data.slice(0, 8)} layout="vertical" margin={{ left: 80, right: 10 }}>
        <XAxis type="number" tick={{ fill: '#4a5068', fontSize: 10 }} axisLine={false} tickLine={false} />
        <YAxis type="category" dataKey={xKey} tick={{ fill: '#8a8fa8', fontSize: 10 }} axisLine={false} tickLine={false} width={75} />
        <Tooltip contentStyle={{ background: '#111827', border: '1px solid rgba(0, 240, 255, 0.2)', borderRadius: 4, fontSize: 11, color: '#e0e0e0' }} />
        <Bar dataKey={yKey} fill="#00f0ff" fillOpacity={0.6} radius={[0, 3, 3, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

function InlinePie({ data }: { data: Array<Record<string, unknown>> }) {
  return (
    <ResponsiveContainer width="100%" height={160}>
      <PieChart>
        <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={30} outerRadius={55} paddingAngle={3} strokeWidth={0}>
          {data.map((_, i) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip contentStyle={{ background: '#111827', border: '1px solid rgba(0, 240, 255, 0.2)', borderRadius: 4, fontSize: 11, color: '#e0e0e0' }} />
      </PieChart>
    </ResponsiveContainer>
  );
}

function InlineLine({ data, config }: { data: Array<Record<string, unknown>>; config: Record<string, unknown> }) {
  const xKey = (config.xKey as string) || 'name';
  const lines = (config.lines as string[]) || ['pageview'];
  const lineColors: Record<string, string> = { ...sourceColors, pageview: '#00f0ff', click: '#00ff88', impression: '#7b2fff' };
  return (
    <ResponsiveContainer width="100%" height={160}>
      <LineChart data={data}>
        <XAxis dataKey={xKey} tick={{ fill: '#4a5068', fontSize: 10 }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fill: '#4a5068', fontSize: 10 }} axisLine={false} tickLine={false} width={30} />
        <Tooltip contentStyle={{ background: '#111827', border: '1px solid rgba(0, 240, 255, 0.2)', borderRadius: 4, fontSize: 11, color: '#e0e0e0' }} />
        {lines.map(l => (
          <Line key={l} type="monotone" dataKey={l} stroke={lineColors[l] || '#8a8fa8'} strokeWidth={1.5} dot={false} />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
}

function InlineTable({ data, config }: { data: Array<Record<string, unknown>>; config: Record<string, unknown> }) {
  const columns = (config.columns as string[]) || Object.keys(data[0] || {});
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
        <thead>
          <tr>
            {columns.map(col => (
              <th key={col} style={{ textAlign: 'left', padding: '4px 8px', color: 'var(--text-muted)', borderBottom: '1px solid rgba(0, 240, 255, 0.1)', fontWeight: 500 }}>
                {col}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.slice(0, 8).map((row, i) => (
            <tr key={i}>
              {columns.map(col => (
                <td key={col} style={{ padding: '3px 8px', borderBottom: '1px solid rgba(0, 240, 255, 0.04)', color: 'var(--text-secondary)', maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {String(row[col] ?? '')}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function InlineChart({ chartData }: { chartData: ChartSpec }) {
  const { type, data, config } = chartData;
  if (!data || data.length === 0) return null;

  switch (type) {
    case 'bar': return <InlineBar data={data} config={config} />;
    case 'pie': return <InlinePie data={data} />;
    case 'line': return <InlineLine data={data} config={config} />;
    case 'table': return <InlineTable data={data} config={config} />;
    default: return null;
  }
}
