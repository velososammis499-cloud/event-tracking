const SUGGESTIONS = [
  '哪个页面用户停留最久',
  '用户从哪里来',
  '点击最多的功能是什么',
  '用户操作习惯分析',
  '哪些页面流失率高',
  '最近趋势变化',
  '表单交互情况',
  '浏览量最高的页面',
];

interface Props {
  onSelect: (query: string) => void;
}

export default function SuggestedQueries({ onSelect }: Props) {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, padding: '12px 0' }}>
      {SUGGESTIONS.map(s => (
        <button
          key={s}
          onClick={() => onSelect(s)}
          style={{
            background: 'rgba(0, 240, 255, 0.06)',
            border: '1px solid rgba(0, 240, 255, 0.15)',
            color: 'var(--text-secondary)',
            padding: '5px 12px',
            borderRadius: 14,
            cursor: 'pointer',
            fontSize: 12,
            transition: 'border-color 0.15s, color 0.15s, background 0.15s',
            whiteSpace: 'nowrap',
          }}
          onMouseEnter={e => {
            e.currentTarget.style.borderColor = 'var(--accent)';
            e.currentTarget.style.color = 'var(--accent)';
            e.currentTarget.style.background = 'rgba(0, 240, 255, 0.12)';
          }}
          onMouseLeave={e => {
            e.currentTarget.style.borderColor = 'rgba(0, 240, 255, 0.15)';
            e.currentTarget.style.color = 'var(--text-secondary)';
            e.currentTarget.style.background = 'rgba(0, 240, 255, 0.06)';
          }}
        >
          {s}
        </button>
      ))}
    </div>
  );
}
