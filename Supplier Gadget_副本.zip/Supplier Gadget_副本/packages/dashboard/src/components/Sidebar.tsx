import { NavLink } from 'react-router-dom';

const navItems = [
  { to: '/', label: '概览', icon: '◈' },
  { to: '/journeys', label: '路径分析', icon: '⇄' },
  { to: '/rankings', label: '用户偏好', icon: '★' },
  { to: '/chains', label: '会话追踪', icon: '⌘' },
  { to: '/events', label: '事件浏览', icon: '☰' },
  { to: '/behavior', label: '行为路径', icon: '⧉' },
  { to: '/preferences', label: '偏好分析', icon: '◉' },
  { to: '/chat', label: '智能对话', icon: '⬡' },
];

export default function Sidebar() {
  return (
    <aside style={styles.sidebar}>
      <div style={styles.logo}>SG Analytics</div>
      <nav style={styles.nav}>
        {navItems.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            style={({ isActive }) => ({
              ...styles.link,
              ...(isActive ? styles.linkActive : {}),
            })}
          >
            <span style={styles.icon}>{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}

const styles: Record<string, React.CSSProperties> = {
  sidebar: {
    width: 200,
    minHeight: '100vh',
    background: 'var(--bg-secondary)',
    borderRight: '1px solid var(--border)',
    display: 'flex',
    flexDirection: 'column',
  },
  logo: {
    padding: '20px 16px',
    fontSize: 18,
    fontWeight: 700,
    color: 'var(--accent)',
    letterSpacing: 1,
  },
  nav: {
    display: 'flex',
    flexDirection: 'column',
    gap: 2,
    padding: '0 8px',
  },
  link: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    padding: '8px 12px',
    borderRadius: 6,
    color: 'var(--text-secondary)',
    fontSize: 14,
    textDecoration: 'none',
    transition: 'background 0.15s, color 0.15s, box-shadow 0.15s',
  },
  linkActive: {
    background: 'rgba(0, 240, 255, 0.08)',
    color: 'var(--accent)',
    boxShadow: '0 0 12px rgba(0, 240, 255, 0.12)',
  },
  icon: {
    fontSize: 16,
    width: 20,
    textAlign: 'center' as const,
    flexShrink: 0,
  },
};
