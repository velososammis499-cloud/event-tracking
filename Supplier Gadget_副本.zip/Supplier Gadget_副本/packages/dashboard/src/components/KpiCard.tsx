import AnimatedNumber from './AnimatedNumber';
import { formatCompactNumber } from '../shared/formatters/primitives/number';

export default function KpiCard({ label, value, animated }: { label: string; value: number; animated?: boolean }) {
  return (
    <div className="glow-card" style={styles.card}>
      <div style={styles.value}>
        {animated ? <AnimatedNumber value={value} /> : formatCompactNumber(value)}
      </div>
      <div style={styles.label}>{label}</div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  card: {
    padding: '20px 24px',
  },
  value: {
    fontSize: 28,
    fontWeight: 700,
    color: 'var(--accent)',
    lineHeight: 1.2,
  },
  label: {
    fontSize: 12,
    color: 'var(--text-secondary)',
    marginTop: 4,
  },
};
