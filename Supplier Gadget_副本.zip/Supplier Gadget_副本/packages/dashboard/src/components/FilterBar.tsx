import { useFilters } from '../hooks/useFilters';

export default function FilterBar() {
  const { filters, setFilters, setTimeRange } = useFilters();

  const now = Date.now();
  const dayMs = 86400000;

  function handlePreset(label: 'today' | '7d' | '30d') {
    if (label === 'today') {
      const start = new Date();
      start.setHours(0, 0, 0, 0);
      setTimeRange(start.getTime(), now);
    } else if (label === '7d') {
      setTimeRange(now - 7 * dayMs, now);
    } else {
      setTimeRange(now - 30 * dayMs, now);
    }
  }

  function handleClear() {
    setFilters({ startTime: undefined, endTime: undefined, appId: undefined });
  }

  const hasFilter = filters.startTime || filters.endTime || filters.appId;

  return (
    <div style={styles.bar}>
      <div style={styles.presets}>
        <button style={styles.btn} onClick={() => handlePreset('today')}>今日</button>
        <button style={styles.btn} onClick={() => handlePreset('7d')}>7天</button>
        <button style={styles.btn} onClick={() => handlePreset('30d')}>30天</button>
      </div>
      <input
        style={styles.input}
        placeholder="App ID"
        value={filters.appId ?? ''}
        onChange={e => setFilters({ appId: e.target.value || undefined })}
      />
      {hasFilter && (
        <button style={styles.clearBtn} onClick={handleClear}>清除筛选</button>
      )}
      {filters.startTime && filters.endTime && (
        <span style={styles.rangeLabel}>
          {new Date(filters.startTime).toLocaleDateString('zh-CN')} — {new Date(filters.endTime).toLocaleDateString('zh-CN')}
        </span>
      )}
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  bar: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    padding: '10px 0',
    marginBottom: 16,
    borderBottom: '1px solid var(--border)',
  },
  presets: {
    display: 'flex',
    gap: 6,
  },
  btn: {
    background: 'rgba(0, 240, 255, 0.06)',
    border: '1px solid var(--border)',
    color: 'var(--text-secondary)',
    padding: '4px 12px',
    borderRadius: 4,
    cursor: 'pointer',
    fontSize: 12,
    transition: 'border-color 0.15s, color 0.15s',
  },
  input: {
    background: 'var(--bg-card)',
    border: '1px solid var(--border)',
    color: 'var(--text-primary)',
    padding: '4px 10px',
    borderRadius: 4,
    fontSize: 12,
    width: 120,
    outline: 'none',
  },
  clearBtn: {
    background: 'transparent',
    border: '1px solid var(--danger)',
    color: 'var(--danger)',
    padding: '4px 10px',
    borderRadius: 4,
    cursor: 'pointer',
    fontSize: 12,
  },
  rangeLabel: {
    fontSize: 12,
    color: 'var(--text-muted)',
  },
};
