import { useState, useRef, useEffect } from 'react';
import { useEvents, usePages } from '../api/queries';
import { useFilters } from '../hooks/useFilters';
import { analyzeQuery, type AnalysisResult } from '../analysis/chat-analyzer';
import ChatMessage from './ChatMessage';
import SuggestedQueries from './SuggestedQueries';
import GlowCard from './GlowCard';

interface Message {
  id: number;
  role: 'user' | 'ai';
  content: string;
  chartData?: AnalysisResult['chartData'];
  animate?: boolean;
}

export default function ChatWindow() {
  const { filters } = useFilters();
  const eventsQuery = useEvents({ limit: 500, startTime: filters.startTime, endTime: filters.endTime, appId: filters.appId });
  const pagesQuery = usePages({ startTime: filters.startTime, endTime: filters.endTime, appId: filters.appId });

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      role: 'ai',
      content: '你好，我是 SG AI 助手。你可以用自然语言询问用户行为数据，比如"点击最多的功能是什么"或"用户从哪里来"。试试下方的快捷问题吧！',
      animate: false,
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(1);

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [messages]);

  function handleSend(text?: string) {
    const query = (text || input).trim();
    if (!query || isTyping) return;

    const userMsg: Message = { id: idRef.current++, role: 'user', content: query };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const events = eventsQuery.data?.items ?? [];
      const pages = pagesQuery.data ?? [];
      const result: AnalysisResult = analyzeQuery(query, events, pages);

      const aiMsg: Message = {
        id: idRef.current++,
        role: 'ai',
        content: result.summary,
        chartData: result.chartData,
        animate: true,
      };
      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
    }, 300 + Math.random() * 400);
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 120px)' }}>
      {/* Scan line header */}
      <div style={{
        padding: '10px 16px',
        borderBottom: '1px solid var(--border)',
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        position: 'relative',
        overflow: 'hidden',
      }}>
        <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--accent)', letterSpacing: 1 }}>SG AI Assistant</span>
        <span style={{ fontSize: 10, color: 'var(--text-muted)', background: 'rgba(0, 240, 255, 0.08)', padding: '2px 8px', borderRadius: 3 }}>ONLINE</span>
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', opacity: 0.04 }}>
          <div style={{
            position: 'absolute',
            left: 0,
            right: 0,
            height: 1,
            background: 'var(--accent)',
            animation: 'scan-line 4s linear infinite',
          }} />
        </div>
      </div>

      {/* Message list */}
      <div
        ref={listRef}
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: 16,
          backgroundImage: `
            linear-gradient(rgba(0, 240, 255, 0.015) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 240, 255, 0.015) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
        }}
      >
        {messages.map(m => (
          <ChatMessage key={m.id} role={m.role} content={m.content} chartData={m.chartData} animate={m.animate} />
        ))}
        {isTyping && (
          <div style={{ display: 'flex', gap: 4, padding: '8px 16px' }}>
            {[0, 1, 2].map(i => (
              <span key={i} style={{
                width: 6,
                height: 6,
                borderRadius: 3,
                background: 'var(--accent)',
                opacity: 0.4,
                animation: `breathe 1s ease-in-out ${i * 0.2}s infinite`,
              }} />
            ))}
          </div>
        )}

        {messages.length <= 1 && <SuggestedQueries onSelect={handleSend} />}
      </div>

      {/* Input */}
      <div style={{
        padding: '12px 16px',
        borderTop: '1px solid var(--border)',
        display: 'flex',
        gap: 8,
        alignItems: 'center',
      }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') handleSend(); }}
          placeholder="输入你的问题…"
          disabled={isTyping}
          className="breathe"
          style={{
            flex: 1,
            background: 'var(--bg-card)',
            border: '1px solid var(--border)',
            color: 'var(--text-primary)',
            padding: '10px 14px',
            borderRadius: 6,
            fontSize: 13,
            outline: 'none',
            fontFamily: 'monospace',
          }}
        />
        <button
          onClick={() => handleSend()}
          disabled={isTyping || !input.trim()}
          style={{
            background: 'rgba(0, 240, 255, 0.1)',
            border: '1px solid var(--accent)',
            color: 'var(--accent)',
            padding: '10px 18px',
            borderRadius: 6,
            cursor: isTyping || !input.trim() ? 'not-allowed' : 'pointer',
            fontSize: 13,
            opacity: isTyping || !input.trim() ? 0.5 : 1,
          }}
        >
          发送
        </button>
      </div>
    </div>
  );
}
