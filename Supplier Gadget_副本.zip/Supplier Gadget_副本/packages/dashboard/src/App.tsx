import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import OverviewPage from './pages/OverviewPage';
import JourneysPage from './pages/JourneysPage';
import RankingsPage from './pages/RankingsPage';
import ChainsPage from './pages/ChainsPage';
import EventsPage from './pages/EventsPage';
import BehaviorPage from './pages/BehaviorPage';
import PreferencesPage from './pages/PreferencesPage';
import ChatPage from './pages/ChatPage';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<OverviewPage />} />
        <Route path="journeys" element={<JourneysPage />} />
        <Route path="rankings" element={<RankingsPage />} />
        <Route path="chains" element={<ChainsPage />} />
        <Route path="events" element={<EventsPage />} />
        <Route path="behavior" element={<BehaviorPage />} />
        <Route path="preferences" element={<PreferencesPage />} />
        <Route path="chat" element={<ChatPage />} />
      </Route>
    </Routes>
  );
}
