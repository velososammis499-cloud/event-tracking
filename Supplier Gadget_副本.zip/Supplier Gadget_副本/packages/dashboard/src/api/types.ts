/**
 * API type contracts for Supplier Gadget Dashboard.
 *
 * These types define the **transport layer** between server and dashboard.
 * They are NOT database schema — server is responsible for mapping
 * internal storage to these DTOs. Frontend must never depend on
 * DB column names or raw payload formats.
 */

// ===== Shared =====

export interface ApiSuccess<T> {
  ok: true;
  data: T;
  meta?: {
    /** unix ms — when the server generated this response */
    generatedAt?: number;
    /** server-assigned request ID for tracing */
    requestId?: string;
  };
}

export interface ApiError {
  ok: false;
  /** Stable machine-readable code for frontend branching (e.g. 'NOT_FOUND', 'INVALID_PARAMS') */
  code: string;
  /** Human-readable description */
  message: string;
  /** Optional structured details (validation errors, etc.) */
  details?: unknown;
}

export type ApiResponse<T> = ApiSuccess<T> | ApiError;

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  limit: number;
  offset: number;
}

export type { QueryParamValue } from './client';

// ===== Shared =====

export type RankingType = 'click' | 'impression';

import type { QueryParamValue } from './client';

/** All known event types from the tracker SDK */
export type EventType =
  | 'pageview'
  | 'click'
  | 'impression'
  | 'form_interaction'
  | 'dwell'
  | 'custom';

export type InteractionType =
  | 'focus'
  | 'change'
  | 'submit'
  | 'init'
  | 'pushState'
  | 'replaceState'
  | 'popstate';

// ===== GET /api/pages =====

export interface PagesRequest {
  [key: string]: QueryParamValue;
  appId?: string;
  /** unix ms */
  startTime?: number;
  /** unix ms */
  endTime?: number;
}

export interface PageStatsDTO {
  pagePath: string;
  pageTitle: string;
  views: number;
  uniqueSessions: number;
  uniqueUsers: number;
}

// ===== GET /api/events =====

export interface EventsRequest {
  [key: string]: QueryParamValue;
  appId?: string;
  pagePath?: string;
  pathMatch?: 'contains' | 'prefix' | 'exact';
  sessionId?: string;
  userId?: string;
  type?: EventType;
  limit?: number;
  offset?: number;
  /** unix ms */
  startTime?: number;
  /** unix ms */
  endTime?: number;
}

/** Normalized event DTO — no raw payload, no snake_case */
export interface EventDTO {
  id: string;
  type: EventType;
  /** unix ms */
  timestamp: number;
  sessionId: string;
  appId: string;
  userId: string | null;
  pagePath: string;
  pageTitle: string | null;
  sourceType: string;
  sourcePath: string | null;
  /** Normalized display label extracted from payload by server */
  label: string | null;
  /** e.g. 'focus'|'change'|'submit' for form_interaction; 'init'|'pushState'|'replaceState'|'popstate' for pageview */
  interactionType: InteractionType | null;
}

// ===== GET /api/journeys =====

export interface JourneysRequest {
  [key: string]: QueryParamValue;
  appId?: string;
  /** unix ms */
  startTime?: number;
  /** unix ms */
  endTime?: number;
  limit?: number;
}

export interface JourneyDTO {
  sourcePath: string;
  targetPath: string;
  count: number;
}

// ===== GET /api/chains =====

export interface ChainsRequest {
  [key: string]: QueryParamValue;
  appId?: string;
  userId?: string;
  limit?: number;
}

export interface ChainDTO {
  sessionId: string;
  appId: string;
  userId: string | null;
  entries: ChainEntryDTO[];
  /** true if server capped the entries array (defense against pathological sessions) */
  truncated?: boolean;
  /** unix ms */
  updatedAt: number;
}

export interface ChainEntryDTO {
  path: string;
  search: string | null;
  hash: string | null;
  title: string | null;
  /** unix ms */
  enteredAt: number;
}

// ===== GET /api/rankings (Slice B) =====

export interface RankingsRequest {
  appId?: string;
  type: RankingType;
  pagePath?: string;
  /** unix ms */
  startTime?: number;
  /** unix ms */
  endTime?: number;
  limit?: number;
}

export interface RankingDTO {
  label: string;
  count: number;
  pagePath: string;
}
