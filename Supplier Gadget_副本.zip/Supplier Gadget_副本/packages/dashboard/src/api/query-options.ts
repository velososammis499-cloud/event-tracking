import type { UseQueryOptions } from '@tanstack/react-query';
import { apiGet, ApiError } from './client';
import { normalizeQueryParams } from './normalize-params';
import { queryKeys } from './query-keys';
import type { PagesRequest, PageStatsDTO, EventsRequest, EventDTO, PaginatedResponse, JourneysRequest, JourneyDTO, ChainsRequest, ChainDTO } from './types';

export const dashboardQueryDefaults = {
  retry: (failureCount: number, error: unknown): boolean => {
    if (error instanceof ApiError && error.code !== 'NETWORK_ERROR') {
      return false;
    }
    return failureCount < 2;
  },
  refetchOnWindowFocus: false,
  staleTime: 30_000,
} as const;

export function pagesQueryOptions(
  params: PagesRequest,
): UseQueryOptions<PageStatsDTO[], ApiError> {
  const normalized = normalizeQueryParams(params);

  return {
    queryKey: queryKeys.pages.list(params),
    queryFn: ({ signal }) =>
      apiGet<PageStatsDTO[]>('/pages', normalized, signal),
    ...dashboardQueryDefaults,
  };
}

export function eventsQueryOptions(
  params: EventsRequest,
): UseQueryOptions<PaginatedResponse<EventDTO>, ApiError> {
  const normalized = normalizeQueryParams(params);

  return {
    queryKey: queryKeys.events.list(params),
    queryFn: ({ signal }) =>
      apiGet<PaginatedResponse<EventDTO>>('/events', normalized, signal),
    placeholderData: (prev) => prev,
    ...dashboardQueryDefaults,
  };
}

export function journeysQueryOptions(
  params: JourneysRequest,
): UseQueryOptions<JourneyDTO[], ApiError> {
  const normalized = normalizeQueryParams(params);

  return {
    queryKey: queryKeys.journeys.list(params),
    queryFn: ({ signal }) =>
      apiGet<JourneyDTO[]>('/journeys', normalized, signal),
    ...dashboardQueryDefaults,
  };
}

export function chainsQueryOptions(
  params: ChainsRequest,
): UseQueryOptions<ChainDTO[], ApiError> {
  const normalized = normalizeQueryParams(params);

  return {
    queryKey: queryKeys.chains.list(params),
    queryFn: ({ signal }) =>
      apiGet<ChainDTO[]>('/chains', normalized, signal),
    ...dashboardQueryDefaults,
  };
}
