import { useQuery } from '@tanstack/react-query';
import { pagesQueryOptions, eventsQueryOptions, journeysQueryOptions, chainsQueryOptions } from './query-options';
import type { PagesRequest, EventsRequest, JourneysRequest, ChainsRequest } from './types';

export function usePages(params: PagesRequest) {
  return useQuery(pagesQueryOptions(params));
}

export function useEvents(params: EventsRequest) {
  return useQuery(eventsQueryOptions(params));
}

export function useJourneys(params: JourneysRequest) {
  return useQuery(journeysQueryOptions(params));
}

export function useChains(params: ChainsRequest) {
  return useQuery(chainsQueryOptions(params));
}
