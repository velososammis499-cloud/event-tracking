import type { PagesRequest, EventsRequest, JourneysRequest, ChainsRequest } from './types';
import { normalizeQueryParams } from './normalize-params';

/**
 * Query key definitions.
 * .all → domain-scoped invalidation
 * .list → exact match with normalized params
 */
export const queryKeys = {
  pages: {
    all: ['pages'] as const,
    list: (params: PagesRequest) => ['pages', 'list', normalizeQueryParams(params)] as const,
  },
  events: {
    all: ['events'] as const,
    list: (params: EventsRequest) => ['events', 'list', normalizeQueryParams(params)] as const,
  },
  journeys: {
    all: ['journeys'] as const,
    list: (params: JourneysRequest) => ['journeys', 'list', normalizeQueryParams(params)] as const,
  },
  chains: {
    all: ['chains'] as const,
    list: (params: ChainsRequest) => ['chains', 'list', normalizeQueryParams(params)] as const,
  },
} as const;
