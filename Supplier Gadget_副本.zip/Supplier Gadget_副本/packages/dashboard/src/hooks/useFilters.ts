import { useSearchParams } from 'react-router-dom';

export interface FilterState {
  startTime?: number;
  endTime?: number;
  appId?: string;
}

export function useFilters() {
  const [searchParams, setSearchParams] = useSearchParams();

  const filters: FilterState = {
    startTime: searchParams.get('startTime') ? Number(searchParams.get('startTime')) : undefined,
    endTime: searchParams.get('endTime') ? Number(searchParams.get('endTime')) : undefined,
    appId: searchParams.get('appId') || undefined,
  };

  function setFilters(patch: Partial<FilterState>) {
    setSearchParams(prev => {
      const next = new URLSearchParams(prev);
      if (patch.startTime !== undefined) next.set('startTime', String(patch.startTime));
      else next.delete('startTime');
      if (patch.endTime !== undefined) next.set('endTime', String(patch.endTime));
      else next.delete('endTime');
      if (patch.appId !== undefined && patch.appId !== '') next.set('appId', patch.appId);
      else next.delete('appId');
      return next;
    }, { replace: true });
  }

  function setTimeRange(start: number, end: number) {
    setFilters({ startTime: start, endTime: end });
  }

  return { filters, setFilters, setTimeRange };
}
