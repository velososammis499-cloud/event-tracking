import type { DeviceInfo } from '../types';

export class SessionContext {
  private _userId?: string;
  private cachedDevice: DeviceInfo;

  constructor() {
    this.cachedDevice = {
      userAgent: navigator.userAgent,
      screen: `${screen.width}x${screen.height}`,
      language: navigator.language,
    };
  }

  get userId(): string | undefined {
    return this._userId;
  }

  setUserId(id: string): void {
    this._userId = id;
  }

  getDeviceInfo(): DeviceInfo {
    return this.cachedDevice;
  }
}
