import { NavigationChainManager } from './navigation-chain';
import { SessionContext } from './context';
import { Reporter } from '../reporter';
import { getSchema } from '../types';
import type {
  TrackerConfig,
  TrackerCore,
  EventType,
  PayloadOf,
  TrackEvent,
  SourceInfo,
  PageInfo,
  NavigationChain,
  DeviceInfo,
  CollectorInit,
} from '../types';

const DEFAULTS: Omit<TrackerConfig, 'endpoint' | 'appId'> = {
  batchInterval: 5000,
  batchSize: 10,
  maxQueueSize: 100,
  maxRetries: 3,
  validate: true,
  debug: false,
};

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

export class Tracker implements TrackerCore {
  config: TrackerConfig;
  private chainManager: NavigationChainManager;
  private context: SessionContext;
  private collectors: (() => void)[] = [];
  private reporter: Reporter | null = null;
  private lastPath: string;

  constructor(config: TrackerConfig) {
    this.config = { ...DEFAULTS, ...config };

    this.chainManager = new NavigationChainManager();
    this.context = new SessionContext();
    this.lastPath = location.pathname;

    if (config.userId) {
      this.setUserId(typeof config.userId === 'function' ? config.userId() : config.userId);
    }

    this.reporter = new Reporter(
      this.config,
      () => this.chainManager.getChain(),
      () => this.context.userId,
    );

    if (this.config.debug) {
      console.log('[SG Tracker] initialized, sessionId:', this.chainManager.getSessionId());
    }
  }

  init(collectors: CollectorInit[]): void {
    for (const init of collectors) {
      const cleanup = init(this);
      if (cleanup) this.collectors.push(cleanup);
    }
  }

  emit<T extends EventType>(type: T, payload: PayloadOf<T>): void {
    if (this.config.validate !== false) {
      const schema = getSchema(type);
      if (schema) {
        const result = schema.safeParse(payload);
        if (!result.success) {
          if (this.config.debug) {
            console.warn(`[SG Tracker] payload validation failed for "${type}":`, result.error.issues);
          }
          return;
        }
      }
    }

    const event: TrackEvent = {
      id: generateId(),
      type,
      schemaVersion: 1,
      timestamp: Date.now(),
      sessionId: this.chainManager.getSessionId(),
      appId: this.config.appId,
      userId: this.context.userId,
      device: this.context.getDeviceInfo(),
      page: this.getPageInfo(),
      source: this.getSource(),
      payload,
    };

    if (this.config.debug) {
      console.log('[SG Tracker] event:', event.type, event.page.path, event.payload);
    }

    this.reporter?.enqueue(event);
  }

  getSource(): SourceInfo {
    return this.chainManager.getSource();
  }

  getChain(): NavigationChain {
    return this.chainManager.getChain();
  }

  getPageInfo(): PageInfo {
    return {
      path: location.pathname,
      search: location.search,
      hash: location.hash,
      title: document.title,
    };
  }

  getDeviceInfo(): DeviceInfo {
    return this.context.getDeviceInfo();
  }

  setUserId(userId: string): void {
    this.context.setUserId(userId);
  }

  handleRouteChange(trigger: string): void {
    const newPath = location.pathname;
    if (newPath === this.lastPath) return;
    this.lastPath = newPath;

    this.chainManager.onNavigation();

    setTimeout(() => {
      this.chainManager.updateCurrentTitle(document.title);
      this.emit('pageview', { trigger: trigger as 'pushState' });
    }, 50);
  }

  destroy(): void {
    for (const cleanup of this.collectors) cleanup();
    this.collectors = [];
    this.reporter?.destroy();
  }
}
