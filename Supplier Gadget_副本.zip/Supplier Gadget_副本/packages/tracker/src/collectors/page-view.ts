import type { CollectorInit } from '../types';

export const initPageViewCollector: CollectorInit = (tracker) => {
  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;

  history.pushState = function (state: unknown, title: string, url?: string | URL | null) {
    originalPushState.call(history, state, title, url);
    tracker.handleRouteChange('pushState');
  };

  history.replaceState = function (state: unknown, title: string, url?: string | URL | null) {
    originalReplaceState.call(history, state, title, url);
    tracker.handleRouteChange('replaceState');
  };

  const onPopState = () => tracker.handleRouteChange('popstate');
  window.addEventListener('popstate', onPopState);

  tracker.emit('pageview', { trigger: 'init' });

  return () => {
    history.pushState = originalPushState;
    history.replaceState = originalReplaceState;
    window.removeEventListener('popstate', onPopState);
  };
};
