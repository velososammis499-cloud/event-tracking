import type { CollectorInit } from '../types';

export const initClickCollector: CollectorInit = (tracker) => {
  function handler(e: MouseEvent) {
    const target = e.target as HTMLElement;
    if (!target) return;

    const element = target.closest('a, button, [role="button"], [data-track], input[type="submit"]') || target;

    tracker.emit('click', {
      tagName: element.tagName,
      text: (element.textContent || '').slice(0, 100).trim() || undefined,
      id: element.id || undefined,
      className: typeof element.className === 'string' ? element.className : undefined,
      href: (element as HTMLAnchorElement).href || undefined,
      dataTrack: element.getAttribute('data-track') || undefined,
    });
  }

  document.addEventListener('click', handler, true);

  return () => document.removeEventListener('click', handler, true);
};
