import { Router, type Request, type Response } from 'express';
import { getEvents, getEventsCount, getPageStats, getJourneys, getChains } from '../db/queries';
import { toEventDTO, toPageStatsDTO, toJourneyDTO, toChainDTO, ok, err } from '../db/dto';

const MAX_EVENTS_LIMIT = 500;
const DEFAULT_EVENTS_LIMIT = 100;

function safeInt(raw: string | undefined, fallback: number): number {
  if (!raw) return fallback;
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0) return fallback;
  return Math.floor(n);
}

const router = Router();

router.get('/events', (req: Request, res: Response): void => {
  const limit = Math.min(
    safeInt(req.query.limit as string, DEFAULT_EVENTS_LIMIT),
    MAX_EVENTS_LIMIT,
  );
  const offset = safeInt(req.query.offset as string, 0);

  const filterOpts = {
    appId: req.query.appId as string | undefined,
    pagePath: req.query.pagePath as string | undefined,
    pathMatch: req.query.pathMatch as 'contains' | 'prefix' | 'exact' | undefined,
    sessionId: req.query.sessionId as string | undefined,
    userId: req.query.userId as string | undefined,
    type: req.query.type as string | undefined,
    startTime: safeInt(req.query.startTime as string, 0) || undefined,
    endTime: safeInt(req.query.endTime as string, 0) || undefined,
  };

  const total = getEventsCount(filterOpts);
  const rows = getEvents({ ...filterOpts, limit, offset });
  const items = rows.map(toEventDTO);

  res.json(ok({
    items,
    total,
    limit,
    offset,
  }));
});

router.get('/pages', (req: Request, res: Response): void => {
  const rows = getPageStats({
    appId: req.query.appId as string | undefined,
    startTime: safeInt(req.query.startTime as string, 0) || undefined,
    endTime: safeInt(req.query.endTime as string, 0) || undefined,
  });

  res.json(ok(rows.map(toPageStatsDTO)));
});

router.get('/journeys', (req: Request, res: Response): void => {
  const rows = getJourneys({
    appId: req.query.appId as string | undefined,
    startTime: safeInt(req.query.startTime as string, 0) || undefined,
    endTime: safeInt(req.query.endTime as string, 0) || undefined,
    limit: safeInt(req.query.limit as string, 50),
  });

  res.json(ok(rows.map(toJourneyDTO)));
});

router.get('/chains', (req: Request, res: Response): void => {
  const rows = getChains({
    appId: req.query.appId as string | undefined,
    userId: req.query.userId as string | undefined,
    limit: safeInt(req.query.limit as string, 20),
  });

  res.json(ok(rows.map(toChainDTO)));
});

export default router;
