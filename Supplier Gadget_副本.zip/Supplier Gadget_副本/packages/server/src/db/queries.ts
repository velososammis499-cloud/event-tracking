import { db } from './db';

// ===== Path Normalization =====

export function normalizePath(path: string): string {
  return path
    .split('/')
    .map((segment) => {
      if (!segment) return segment;

      // 1. pure numeric id
      if (/^\d+$/.test(segment)) return ':id';

      // 2. uuid
      if (
        /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
          segment
        )
      ) {
        return ':id';
      }

      // 3. very high entropy hashes only (strict)
      if (/^[a-f0-9]{28,}$/i.test(segment)) return ':id';

      // 4. numeric with prefix patterns (order-123, user_456)
      if (/^[a-z]+[-_]\d+$/.test(segment)) return ':id';

      return segment;
    })
    .join('/');
}

// ===== Insert =====

export interface InsertEvent {
  id: string;
  type: string;
  schema_version?: number;
  timestamp: number;
  session_id: string;
  app_id: string;
  user_id?: string;
  device_user_agent?: string;
  device_screen?: string;
  device_language?: string;
  page_path: string;
  page_search?: string;
  page_hash?: string;
  page_title?: string;
  source_type: string;
  source_path?: string;
  source_search?: string;
  source_title?: string;
  source_referrer_url?: string;
  source_chain_index?: number;
  payload?: string;
}

const insertEventStmt = db.prepare(`
  INSERT OR IGNORE INTO events (
    id, type, timestamp, session_id, app_id, user_id,
    device_user_agent, device_screen, device_language,
    page_path, page_search, page_hash, page_title,
    source_type, source_path, source_search, source_title,
    source_referrer_url, source_chain_index, payload
  ) VALUES (
    @id, @type, @timestamp, @session_id, @app_id, @user_id,
    @device_user_agent, @device_screen, @device_language,
    @page_path, @page_search, @page_hash, @page_title,
    @source_type, @source_path, @source_search, @source_title,
    @source_referrer_url, @source_chain_index, @payload
  )
`);

const upsertChainStmt = db.prepare(`
  INSERT INTO chains (session_id, app_id, user_id, entries, updated_at)
  VALUES (@session_id, @app_id, @user_id, @entries, @updated_at)
  ON CONFLICT(session_id) DO UPDATE SET
    user_id = @user_id,
    entries = @entries,
    updated_at = @updated_at
`);

const insertMany = db.transaction((items: InsertEvent[]) => {
  for (const item of items) {
    insertEventStmt.run(item);
  }
});

export function insertEvents(events: InsertEvent[]): void {
  insertMany(events);
}

export function upsertChain(params: {
  session_id: string;
  app_id: string;
  user_id?: string;
  entries: string;
  updated_at: number;
}): void {
  upsertChainStmt.run(params);
}

// ===== Queries =====

export function getEventsCount(options: {
  appId?: string;
  pagePath?: string;
  pathMatch?: 'contains' | 'prefix' | 'exact';
  sessionId?: string;
  userId?: string;
  type?: string;
  startTime?: number;
  endTime?: number;
}): number {
  const clauses: string[] = [];
  const params: Record<string, unknown> = {};

  if (options.appId) { clauses.push('app_id = @appId'); params.appId = options.appId; }
  if (options.pagePath) {
    const match = options.pathMatch ?? 'contains';
    if (match === 'exact') {
      clauses.push('page_path = @pagePath'); params.pagePath = options.pagePath;
    } else if (match === 'prefix') {
      clauses.push('page_path LIKE @pagePath'); params.pagePath = `${options.pagePath}%`;
    } else {
      clauses.push('page_path LIKE @pagePath'); params.pagePath = `%${options.pagePath}%`;
    }
  }
  if (options.sessionId) { clauses.push('session_id = @sessionId'); params.sessionId = options.sessionId; }
  if (options.userId) { clauses.push('user_id = @userId'); params.userId = options.userId; }
  if (options.type) { clauses.push('type = @type'); params.type = options.type; }
  if (options.startTime) { clauses.push('timestamp >= @startTime'); params.startTime = options.startTime; }
  if (options.endTime) { clauses.push('timestamp <= @endTime'); params.endTime = options.endTime; }

  const where = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';

  const row = db.prepare(`SELECT COUNT(*) as total FROM events ${where}`).get(params) as { total: number };
  return row.total;
}

export function getEvents(options: {
  appId?: string;
  pagePath?: string;
  pathMatch?: 'contains' | 'prefix' | 'exact';
  sessionId?: string;
  userId?: string;
  type?: string;
  limit?: number;
  offset?: number;
  startTime?: number;
  endTime?: number;
}): InsertEvent[] {
  const clauses: string[] = [];
  const params: Record<string, unknown> = {};

  if (options.appId) { clauses.push('app_id = @appId'); params.appId = options.appId; }
  if (options.pagePath) {
    const match = options.pathMatch ?? 'contains';
    if (match === 'exact') {
      clauses.push('page_path = @pagePath'); params.pagePath = options.pagePath;
    } else if (match === 'prefix') {
      clauses.push('page_path LIKE @pagePath'); params.pagePath = `${options.pagePath}%`;
    } else {
      clauses.push('page_path LIKE @pagePath'); params.pagePath = `%${options.pagePath}%`;
    }
  }
  if (options.sessionId) { clauses.push('session_id = @sessionId'); params.sessionId = options.sessionId; }
  if (options.userId) { clauses.push('user_id = @userId'); params.userId = options.userId; }
  if (options.type) { clauses.push('type = @type'); params.type = options.type; }
  if (options.startTime) { clauses.push('timestamp >= @startTime'); params.startTime = options.startTime; }
  if (options.endTime) { clauses.push('timestamp <= @endTime'); params.endTime = options.endTime; }

  const where = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';
  const limit = options.limit ?? 100;
  const offset = options.offset ?? 0;

  return db.prepare(`SELECT * FROM events ${where} ORDER BY timestamp DESC LIMIT @limit OFFSET @offset`)
    .all({ ...params, limit, offset }) as InsertEvent[];
}

export function getPageStats(options: {
  appId?: string;
  startTime?: number;
  endTime?: number;
}): Array<{
  page_path: string;
  page_title: string;
  views: number;
  unique_sessions: number;
  unique_users: number;
}> {
  const clauses: string[] = ["type = 'pageview'"];
  const params: Record<string, unknown> = {};

  if (options.appId) { clauses.push('app_id = @appId'); params.appId = options.appId; }
  if (options.startTime) { clauses.push('timestamp >= @startTime'); params.startTime = options.startTime; }
  if (options.endTime) { clauses.push('timestamp <= @endTime'); params.endTime = options.endTime; }

  const where = `WHERE ${clauses.join(' AND ')}`;

  const rows = db.prepare(`
    SELECT
      page_path,
      page_title,
      COUNT(*) as views,
      COUNT(DISTINCT session_id) as unique_sessions,
      COUNT(DISTINCT user_id) as unique_users
    FROM events ${where}
    GROUP BY page_path
    ORDER BY views DESC
    LIMIT 50
  `).all(params) as Array<{
    page_path: string;
    page_title: string;
    views: number;
    unique_sessions: number;
    unique_users: number;
  }>;

  // Merge rows that normalize to the same path
  const merged = new Map<string, { page_path: string; page_title: string; views: number; unique_sessions: number; unique_users: number }>();
  for (const row of rows) {
    const key = normalizePath(row.page_path);
    const existing = merged.get(key);
    if (existing) {
      existing.views += row.views;
      existing.unique_sessions += row.unique_sessions;
      existing.unique_users += row.unique_users;
    } else {
      merged.set(key, { ...row, page_path: key });
    }
  }

  return Array.from(merged.values()).sort((a, b) => b.views - a.views);
}

export function getJourneys(options: {
  appId?: string;
  startTime?: number;
  endTime?: number;
  limit?: number;
}): Array<{
  source_path: string;
  target_path: string;
  count: number;
}> {
  const clauses: string[] = [
    "type = 'pageview'",
    "source_type = 'internal'",
    "source_path IS NOT NULL",
    "source_path != ''",
  ];
  const params: Record<string, unknown> = {};

  if (options.appId) { clauses.push('app_id = @appId'); params.appId = options.appId; }
  if (options.startTime) { clauses.push('timestamp >= @startTime'); params.startTime = options.startTime; }
  if (options.endTime) { clauses.push('timestamp <= @endTime'); params.endTime = options.endTime; }

  const where = `WHERE ${clauses.join(' AND ')}`;
  const FINAL_LIMIT = options.limit ?? 50;
  const dbLimit = Math.min(Math.max(FINAL_LIMIT * 3, 500), 2000);

  const rows = db.prepare(`
    SELECT
      source_path,
      page_path as target_path
    FROM events
    ${where}
    LIMIT ${dbLimit}
  `).all(params) as Array<{
    source_path: string;
    target_path: string;
  }>;

  const merged = new Map<string, {
    source_path: string;
    target_path: string;
    count: number;
  }>();

  for (const row of rows) {
    const src = normalizePath(row.source_path);
    const tgt = normalizePath(row.target_path);

    const key = `${src}::${tgt}`;

    const existing = merged.get(key);
    if (existing) {
      existing.count += 1;
    } else {
      merged.set(key, {
        source_path: src,
        target_path: tgt,
        count: 1,
      });
    }
  }

  return Array.from(merged.values())
    .sort((a, b) => b.count - a.count)
    .slice(0, FINAL_LIMIT);
}

export function getChains(options: {
  appId?: string;
  userId?: string;
  limit?: number;
}): Array<{
  session_id: string;
  app_id: string;
  user_id: string | null;
  entries: string;
  updated_at: number;
}> {
  const clauses: string[] = [];
  const params: Record<string, unknown> = {};

  if (options.appId) { clauses.push('app_id = @appId'); params.appId = options.appId; }
  if (options.userId) { clauses.push('user_id = @userId'); params.userId = options.userId; }

  const where = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';
  const limit = options.limit ?? 20;

  return db.prepare(`SELECT * FROM chains ${where} ORDER BY updated_at DESC LIMIT @limit`)
    .all({ ...params, limit }) as Array<{
      session_id: string;
      app_id: string;
      user_id: string | null;
      entries: string;
      updated_at: number;
    }>;
}
