import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { closeDb } from './db/db';
import collectRouter from './routes/collect';
import analyticsRouter from './routes/analytics';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const PORT = Number(process.env.PORT) || 3001;

app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.use('/collect', collectRouter);
app.use('/api', analyticsRouter);

// Serve tracker UMD — users add <script src="http://host:3001/tracker.js">
app.get('/tracker.js', (_req, res) => {
  const trackerPath = path.resolve(__dirname, '../../tracker/dist/tracker.umd.js');
  res.sendFile(trackerPath, (err) => {
    if (err) {
      res.status(404).json({ ok: false, code: 'NOT_FOUND', message: 'Tracker not built. Run npm run build:tracker first.' });
    }
  });
});

// Serve tracker auto-init loader
app.get('/sg.js', (_req, res) => {
  const loaderPath = path.resolve(__dirname, '../public/sg.js');
  res.setHeader('Content-Type', 'application/javascript');
  res.sendFile(loaderPath, (err) => {
    if (err) {
      res.status(404).json({ ok: false, code: 'NOT_FOUND', message: 'Loader script not found.' });
    }
  });
});

app.get('/health', (_req, res) => {
  res.json({ ok: true, data: { status: 'ok', uptime: process.uptime() } });
});

const server = app.listen(PORT, () => {
  console.log(`[SG Server] running on http://localhost:${PORT}`);
});

function gracefulShutdown(): void {
  console.log('[SG Server] shutting down...');
  server.close(() => {
    closeDb();
    process.exit(0);
  });
}

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);
