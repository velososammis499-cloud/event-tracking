/**
 * Supplier Gadget zero-config loader.
 *
 * Usage (one line in any HTML page):
 *   <script src="http://your-server:3001/sg.js" data-app-id="my-app"></script>
 *
 * Optional data attributes:
 *   data-app-id      — required, your application identifier
 *   data-endpoint    — collect endpoint, defaults to same origin /collect
 *   data-user-id     — optional user identifier
 *   data-debug       — "true" to enable debug logging
 *
 * This script:
 * 1. Reads config from its own <script> tag data attributes
 * 2. Loads tracker.umd.js from the same server
 * 3. Calls initTracker() with the config
 */
(function () {
  var currentScript = document.currentScript;
  if (!currentScript) {
    console.error('[SG] Cannot find current script tag. Are you using a browser that supports document.currentScript?');
    return;
  }

  var appId = currentScript.getAttribute('data-app-id');
  if (!appId) {
    console.error('[SG] data-app-id is required. Add data-app-id="your-app-id" to the script tag.');
    return;
  }

  var scriptSrc = currentScript.getAttribute('src') || '';
  var baseUrl = scriptSrc.replace(/sg\.js$/, '');
  var endpoint = currentScript.getAttribute('data-endpoint') || (baseUrl + 'collect');
  var userId = currentScript.getAttribute('data-user-id') || undefined;
  var debug = currentScript.getAttribute('data-debug') === 'true';

  var trackerUrl = baseUrl + 'tracker.js';

  var s = document.createElement('script');
  s.src = trackerUrl;
  s.onload = function () {
    var init = (typeof SGTracker !== 'undefined' && typeof SGTracker.initTracker === 'function')
      ? SGTracker.initTracker
      : (typeof initTracker === 'function' ? initTracker : null);
    if (init) {
      init({
        endpoint: endpoint,
        appId: appId,
        userId: userId,
        debug: debug,
      });
      if (debug) console.log('[SG] Tracker initialized. appId=' + appId + ', endpoint=' + endpoint);
    } else {
      console.error('[SG] initTracker not found after loading tracker.js');
    }
  };
  s.onerror = function () {
    console.error('[SG] Failed to load tracker from ' + trackerUrl);
  };
  document.head.appendChild(s);
})();
